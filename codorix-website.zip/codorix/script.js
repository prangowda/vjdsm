const nav = document.getElementById('nav');
const menu = document.querySelector('.menu');
const setMenu = open => { nav.classList.toggle('open', open); menu.setAttribute('aria-expanded', open); };
menu.addEventListener('click', () => setMenu(!nav.classList.contains('open')));
nav.addEventListener('click', e => { if (e.target.tagName === 'A') setMenu(false); });

document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contact-form');
const status = document.getElementById('status');
form.addEventListener('submit', async e => {
  e.preventDefault();
  status.textContent = 'Sending…';
  try {
    const res = await fetch(form.action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('failed');
    form.reset();
    status.textContent = 'Message sent. We’ll reply within one business day.';
  } catch {
    status.textContent = 'Message not sent. Try again or email hello@codorix.com.';
  }
});
