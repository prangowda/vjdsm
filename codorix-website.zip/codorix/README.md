# Codorix landing page

Static site (HTML, CSS, JS). No build step.

## Files
index.html, styles.css, script.js, favicon.svg, robots.txt, sitemap.xml

## Before you deploy
1. Contact form: create a free form at formspree.io and replace YOUR_FORM_ID in index.html.
2. Replace hello@codorix.com (index.html, script.js) with your real email.
3. Replace www.codorix.com in robots.txt and sitemap.xml with your domain.
4. Check that the name and domain are available before you commit to them.

## Deploy
- Netlify: drag the folder onto app.netlify.com/drop.
- Vercel: run `npx vercel` in this folder.
- GitHub Pages: push the files to a repo, then Settings > Pages > Deploy from branch.
- Any host (cPanel, Hostinger, S3): upload all files to the public_html or web root folder.
